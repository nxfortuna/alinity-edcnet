"""
Impresion de controles: une los "INFORME LISTA DE RESULTADOS" que exporta el
Alinity ci (ej. a una USB) en un solo PDF y, debajo de cada informe, agrega una
tabla con los lotes usados en esa corrida (reactivo, control, CIP, CIN), su
numero y su vencimiento. Los lotes salen de los logs de la interfaz, cruzando
el IDM y la hora de cada fila del informe.

Requiere pypdf (pip install pypdf).
"""

import io
import re
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path

from pypdf import PdfReader, PdfWriter

import alinity_edcnet as core

PATRON_INFORMES = "INFORME_LISTA_DE_RESULTADOS*.pdf"
HORA_RE = re.compile(r"(\d{2}\.\d{2}\.\d{4} \d{1,2}:\d{2})")
ORDEN_TIPOS = {"Reactivo": 0, "Control": 1, "CIP": 2, "CIN": 3}


@dataclass
class FilaInforme:
    idm: str
    ensayo_pdf: str
    resultado: str
    hora: datetime


@dataclass
class Informe:
    ruta: Path
    filas: list[FilaInforme] = field(default_factory=list)
    paginas: int = 0
    y_fin: float = 0.0          # altura (pt) donde termina el contenido de la ultima pagina
    ancho: float = 792.0
    alto: float = 612.0
    codigo: str = ""            # codigo de ensayo Alinity (ej. 470)
    prueba: str = ""            # nombre para el titulo
    lotes: list[tuple[str, str, str]] = field(default_factory=list)   # (tipo, lote, vence)
    sin_datos: list[str] = field(default_factory=list)                # IDM sin resultado en logs

    @property
    def fecha(self):
        return min((f.hora for f in self.filas), default=None)


# --------------------------------------------------------------------------
# Lectura del informe
# --------------------------------------------------------------------------

def leer_informe(ruta: Path) -> Informe:
    lector = PdfReader(str(ruta))
    inf = Informe(ruta, paginas=len(lector.pages))
    caja = lector.pages[-1].mediabox
    inf.ancho, inf.alto = float(caja.width), float(caja.height)
    for n, pagina in enumerate(lector.pages):
        textos = []
        pagina.extract_text(visitor_text=lambda t, cm, tm, fd, fs: textos.append(
            (tm[5] * cm[3] + cm[5], tm[4] * cm[0] + cm[4], t.strip())) if t.strip() else None)
        renglones: dict[float, list] = {}
        for y, x, t in textos:
            renglones.setdefault(round(y), []).append((x, t))
        for y in sorted(renglones, reverse=True):
            celdas = sorted(renglones[y])
            hora = next((HORA_RE.search(t) for _, t in celdas if HORA_RE.search(t)), None)
            idm = next((t for x, t in celdas if 110 <= x <= 200), "")
            if hora and idm and not idm.startswith("IDM"):
                # la hora sigue en el renglon de abajo ("AM"/"PM")
                ampm = next((t for yy in (y - 11, y - 12) for _, t in renglones.get(yy, [])
                             if t in ("AM", "PM")), "")
                txt = f"{hora.group(1)} {ampm}".strip()
                formato = "%d.%m.%Y %I:%M %p" if ampm else "%d.%m.%Y %H:%M"
                inf.filas.append(FilaInforme(
                    idm=idm, hora=datetime.strptime(txt, formato),
                    ensayo_pdf=next((t for x, t in celdas if 340 <= x <= 440), ""),
                    resultado=next((t for x, t in celdas if 440 <= x <= 510), "")))
        if n == len(lector.pages) - 1:
            # fin del contenido: debajo de "Firma:" (o del ultimo texto antes del pie)
            firma = [y for y, _, t in textos if t.startswith("Firma")]
            cuerpo = [y for y, _, t in textos if y > 60]
            inf.y_fin = (min(firma) - 18) if firma else (min(cuerpo, default=inf.alto) - 12)
    return inf


# --------------------------------------------------------------------------
# Cruce con los logs
# --------------------------------------------------------------------------

def _tipo_control(cfg: dict, r: core.ResultadoQC) -> str:
    if r.control in cfg.get("ensayos", {}).get(r.ensayo, {}).get("controles_kit", {}):
        return "Control"
    if r.control.upper().startswith("CIP"):
        return "CIP"
    if r.control.upper().startswith("CIN"):
        return "CIN"
    return "Control"


def _fecha(aaaammdd: str) -> str:
    try:
        return datetime.strptime(aaaammdd[:8], "%Y%m%d").strftime("%d/%m/%Y")
    except ValueError:
        return ""


def _norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]", "", s.lower())


def completar_lotes(cfg: dict, informes: list[Informe], resultados: list) -> None:
    """Busca en los logs cada fila del informe: mismo IDM, hora +-3 min, mismo
    valor y mismo ensayo (el CIN/CIP se corre en todas las pruebas a la vez)."""
    for inf in informes:
        usados = []
        for f in inf.filas:
            valor = f.resultado.split()[0] if f.resultado else ""
            candidatos = [r for r in resultados if r.muestra == f.idm
                          and abs(r.fecha - f.hora) <= timedelta(minutes=3)]
            for filtro in (lambda r: _norm(r.nombre_ensayo) == _norm(f.ensayo_pdf),
                           lambda r: r.valor == valor):
                if any(filtro(r) for r in candidatos):
                    candidatos = [r for r in candidatos if filtro(r)]
            if not candidatos:
                inf.sin_datos.append(f.idm)
                continue
            usados.append(min(candidatos, key=lambda r: abs(r.fecha - f.hora)))
        # el ensayo del informe es el de la mayoria (los controles de kit son de una sola prueba)
        codigos = [r.ensayo for r in usados]
        if codigos:
            mayoria = max(set(codigos), key=codigos.count)
            usados = [r for r in usados if r.ensayo == mayoria]
        if usados:
            inf.codigo = usados[0].ensayo
            inf.prueba = cfg.get("ensayos", {}).get(inf.codigo, {}).get("nombre") or usados[0].nombre_ensayo
        else:
            inf.prueba = inf.filas[0].ensayo_pdf if inf.filas else inf.ruta.stem
        lotes = {}
        for r in usados:
            if r.lote_reactivo:
                lotes[("Reactivo", r.lote_reactivo)] = _fecha(r.vence_reactivo)
            tipo = _tipo_control(cfg, r)
            lote = re.sub(r"^[A-Za-z_]+", "", r.lote_control) if tipo in ("CIP", "CIN") else r.lote_control
            if lote:
                lotes[(tipo, lote)] = _fecha(r.vence_control)
        inf.lotes = sorted(((t, l, v) for (t, l), v in lotes.items()), key=lambda x: (ORDEN_TIPOS[x[0]], x[1]))


def cargar_informes(cfg: dict, carpeta: Path) -> list[Informe]:
    informes = [leer_informe(p) for p in sorted(carpeta.glob(PATRON_INFORMES))]
    fechas = {f.hora.date() for i in informes for f in i.filas}
    # logs de los dias de los informes (tambien el dia siguiente, por si cambio el log)
    logs = core.logs_de_fechas(cfg, fechas | {d + timedelta(days=1) for d in fechas})
    completar_lotes(cfg, informes, core.cargar_controles(logs))
    orden = list(cfg.get("ensayos", {}))
    return sorted(informes, key=lambda i: (orden.index(i.codigo) if i.codigo in orden else 99, i.ruta.name))


# --------------------------------------------------------------------------
# Tabla de lotes: PDF de una pagina dibujado a mano (Helvetica, sin dependencias)
# --------------------------------------------------------------------------

def _pdf_texto(s: str) -> bytes:
    b = s.encode("cp1252", "replace")
    return b"(" + b.replace(b"\\", b"\\\\").replace(b"(", b"\\(").replace(b")", b"\\)") + b")"


ALTO_TITULO, ALTO_FILA = 20, 17


def alto_tabla(inf: Informe) -> float:
    return ALTO_TITULO + ALTO_FILA * (1 + max(1, len(inf.lotes))) + 6


def _ops_tabla(inf: Informe, x0: float, y_top: float, ancho: float) -> bytes:
    cols = [ancho * 0.28, ancho * 0.40, ancho * 0.32]
    ops = [b"0.5 w 0.35 0.35 0.35 RG"]

    def texto(x, y, s, negrita=False, tam=10):
        ops.append(b"BT /%s %d Tf %.1f %.1f Td " % (b"F2" if negrita else b"F1", tam, x, y)
                   + _pdf_texto(s) + b" Tj ET")

    y = y_top
    # titulo: nombre de la prueba
    ops.append(b"0.88 0.91 0.95 rg %.1f %.1f %.1f %.1f re f" % (x0, y - ALTO_TITULO, ancho, ALTO_TITULO))
    ops.append(b"%.1f %.1f %.1f %.1f re S" % (x0, y - ALTO_TITULO, ancho, ALTO_TITULO))
    ops.append(b"0 0 0 rg")
    texto(x0 + 6, y - ALTO_TITULO + 6, inf.prueba, negrita=True, tam=12)
    y -= ALTO_TITULO
    filas = [("Lote", "Número de lote", "Fecha de vencimiento")] + \
        ([(t, l, v) for t, l, v in inf.lotes] or [("Sin datos en los logs", "", "")])
    for i, fila in enumerate(filas):
        if i == 0:
            ops.append(b"0.95 0.95 0.95 rg %.1f %.1f %.1f %.1f re f 0 0 0 rg" % (x0, y - ALTO_FILA, ancho, ALTO_FILA))
        x = x0
        for c, ancho_c in zip(fila, cols):
            ops.append(b"%.1f %.1f %.1f %.1f re S" % (x, y - ALTO_FILA, ancho_c, ALTO_FILA))
            texto(x + 6, y - ALTO_FILA + 5, c, negrita=(i == 0))
            x += ancho_c
        y -= ALTO_FILA
    return b"\n".join(ops)


def pdf_tabla(ancho_pag: float, alto_pag: float, ops: bytes) -> bytes:
    """PDF minimo de una pagina con el contenido dado (fuentes Helvetica WinAnsi)."""
    objetos = [
        b"<< /Type /Catalog /Pages 2 0 R >>",
        b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
        b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 %.0f %.0f] /Contents 4 0 R "
        b"/Resources << /Font << /F1 5 0 R /F2 6 0 R >> >> >>" % (ancho_pag, alto_pag),
        b"<< /Length %d >>\nstream\n" % len(ops) + ops + b"\nendstream",
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>",
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>",
    ]
    salida = io.BytesIO()
    salida.write(b"%PDF-1.4\n")
    posiciones = []
    for n, obj in enumerate(objetos, 1):
        posiciones.append(salida.tell())
        salida.write(b"%d 0 obj\n" % n + obj + b"\nendobj\n")
    xref = salida.tell()
    salida.write(b"xref\n0 %d\n0000000000 65535 f \n" % (len(objetos) + 1))
    for p in posiciones:
        salida.write(b"%010d 00000 n \n" % p)
    salida.write(b"trailer\n<< /Size %d /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF\n" % (len(objetos) + 1, xref))
    return salida.getvalue()


# --------------------------------------------------------------------------
# Union
# --------------------------------------------------------------------------

MARGEN_X, MARGEN_INF = 19.4, 40


def unir(informes: list[Informe], destino: Path) -> Path:
    escritor = PdfWriter()
    for inf in informes:
        lector = PdfReader(str(inf.ruta))
        for n, pagina in enumerate(lector.pages):
            escritor.add_page(pagina)
        ancho = inf.ancho - 2 * MARGEN_X
        alto = alto_tabla(inf)
        if inf.y_fin - alto >= MARGEN_INF:
            # cabe debajo del informe, en la misma pagina
            tabla = PdfReader(io.BytesIO(pdf_tabla(inf.ancho, inf.alto,
                                                   _ops_tabla(inf, MARGEN_X, inf.y_fin, ancho)))).pages[0]
            escritor.pages[-1].merge_page(tabla)
        else:
            # pagina aparte con la tabla arriba
            tabla = PdfReader(io.BytesIO(pdf_tabla(inf.ancho, inf.alto,
                                                   _ops_tabla(inf, MARGEN_X, inf.alto - 40, ancho)))).pages[0]
            escritor.add_page(tabla)
    with open(destino, "wb") as fh:
        escritor.write(fh)
    return destino
